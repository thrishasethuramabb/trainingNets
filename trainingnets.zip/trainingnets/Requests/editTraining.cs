﻿namespace trainingnets.Requests
{
    public class editTraining
    {
        public addTraining training { get; set; }
        public int id { get; set; }
    }
}
